import jwt from 'jsonwebtoken';

// 로그인에서 사용한 것과 동일한 시크릿 키 사용해야 함
const JWT_SECRET = "your-secret-key-change-this-in-production";

export const handler = async (event) => {
  try {
    // 헤더에서 토큰 추출
    const authHeader = event.headers.Authorization || event.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return generatePolicy('user', 'Deny', event.methodArn);
    }
    
    const token = authHeader.split(' ')[1];
    
    // 토큰 검증
    const decoded = jwt.verify(token, JWT_SECRET);
    console.log('Decoded token:', decoded);
    
    // 성공 시 Allow 정책 반환
    return generatePolicy(decoded.userID, 'Allow', event.methodArn);
  } catch (error) {
    console.error('Token verification failed:', error);
    return generatePolicy('user', 'Deny', event.methodArn);
  }
};

// IAM 정책 생성 헬퍼 함수
function generatePolicy(principalId, effect, resource) {
  const authResponse = {
    principalId: principalId
  };
  
  if (effect && resource) {
    const policyDocument = {
      Version: '2012-10-17',
      Statement: [{
        Action: 'execute-api:Invoke',
        Effect: effect,
        Resource: resource
      }]
    };
    authResponse.policyDocument = policyDocument;
  }
  
  // 컨텍스트에 추가 정보 포함 가능 (Lambda에서 event.requestContext.authorizer로 접근 가능)
  authResponse.context = {
    userID: principalId
  };
  
  return authResponse;
}