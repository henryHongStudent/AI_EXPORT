import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, GetCommand } from "@aws-sdk/lib-dynamodb";

// DynamoDB 클라이언트
const client = new DynamoDBClient({ region: "ap-southeast-2" });
const ddb = DynamoDBDocumentClient.from(client);

export const handler = async (event) => {
  try {
    // JWT Authorizer에서 전달된 userID 사용
    const userID = event.requestContext.authorizer?.userID;
    
    if (!userID) {
      return {
        statusCode: 400,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Headers": "Content-Type,Authorization",
          "Access-Control-Allow-Methods": "GET,OPTIONS"
        },
        body: JSON.stringify({ message: "인증된 사용자 ID가 없습니다." })
      };
    }

    // 사용자 정보 조회
    const params = {
      TableName: "user_data",
      Key: { userID: userID }
    };

    const result = await ddb.send(new GetCommand(params));
    
    if (!result.Item) {
      return {
        statusCode: 404,
        headers: {
          "Access-Control-Allow-Origin": "*"
        },
        body: JSON.stringify({ 
          success: false,
          message: "사용자를 찾을 수 없습니다."
        })
      };
    }

    // 비밀번호 제거
    const { password, ...userWithoutPassword } = result.Item;

    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({
        success: true,
        user: userWithoutPassword
      })
    };
  } catch (error) {
    console.error("사용자 정보 조회 오류:", error);
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({ 
        success: false,
        message: "서버 오류가 발생했습니다.",
        error: error.message 
      })
    };
  }
};
