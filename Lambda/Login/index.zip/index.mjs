import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  ScanCommand,
} from "@aws-sdk/lib-dynamodb";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

// JWT 시크릿 키 (실제 환경에서는 환경 변수나 AWS Secrets Manager 사용 권장)
const JWT_SECRET = "your-secret-key-change-this-in-production";
// 토큰 만료 시간 (예: 1시간)
const TOKEN_EXPIRY = '1h';

// DynamoDB 클라이언트
const client = new DynamoDBClient({ region: "ap-southeast-2" });
const ddb = DynamoDBDocumentClient.from(client);

// 입력값 유효성 검사
function validateInput({ email, password }) {
  const trimmed = {
    email: email?.trim(),
    password: password,
  };

  for (const [key, value] of Object.entries(trimmed)) {
    if (!value) return `${key} is required`;
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(trimmed.email)) {
    return "Invalid email format";
  }

  return null;
}

// 사용자 검색
async function findUserByEmail(email) {
  const scanParams = {
    TableName: "user_data",
    FilterExpression: "email = :email",
    ExpressionAttributeValues: {
      ":email": email,
    },
  };

  const result = await ddb.send(new ScanCommand(scanParams));
  return result.Items.length > 0 ? result.Items[0] : null;
}

// Lambda 핸들러
export const handler = async (event) => {
  const error = validateInput(event);
  if (error) {
    return {
      statusCode: 400,
      body: JSON.stringify({ message: error }),
    };
  }

  const { email, password } = event;

  try {
    const trimmedEmail = email.trim(); // 이메일 공백 제거

    // 이메일로 사용자 검색
    const user = await findUserByEmail(trimmedEmail);
    
    // 사용자가 없는 경우
    if (!user) {
      return {
        statusCode: 401,
        body: JSON.stringify({ message: "Invalid email or password" }),
      };
    }

    // 비밀번호 검증
    const isPasswordValid = await bcrypt.compare(password, user.password);
    
    if (!isPasswordValid) {
      return {
        statusCode: 401,
        body: JSON.stringify({ message: "Invalid email or password" }),
      };
    }

    // JWT 토큰 생성
    const token = jwt.sign(
      { 
        userID: user.userID,
        email: user.email,
        name: user.name
      },
      JWT_SECRET,
      { expiresIn: TOKEN_EXPIRY }
    );

    // 비밀번호 제외한 사용자 정보
    const { password: _, ...userWithoutPassword } = user;
    
    return {
      statusCode: 200,
      body: JSON.stringify({ 
        message: "Login successful",
        token,
        user: userWithoutPassword
      }),
    };
  } catch (error) {
    console.error("Login error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "Failed to login", error }),
    };
  }
};
