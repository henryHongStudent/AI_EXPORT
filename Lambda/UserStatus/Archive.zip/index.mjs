import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, GetCommand, UpdateCommand } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

export const handler = async (event) => {
  // CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'PUT,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  // Handle OPTIONS request for CORS
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ message: 'CORS enabled' })
    };
  }

  try {
    // Parse request body
    const body = JSON.parse(event.body);
    const { userID } = body;

    if (!userID) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({
          success: false,
          message: 'User ID is required'
        })
      };
    }

    // Get current user status
    const getParams = {
      TableName: 'user_data',
      Key: { userID }
    };

    const { Item: user } = await docClient.send(new GetCommand(getParams));

    if (!user) {
      return {
        statusCode: 404,
        headers,
        body: JSON.stringify({
          success: false,
          message: 'User not found'
        })
      };
    }

    // Toggle active status
    const currentStatus = user.active || false;
    const newStatus = !currentStatus;

    // Update user status
    const updateParams = {
      TableName: 'user_data',
      Key: { userID },
      UpdateExpression: 'SET active = :active',
      ExpressionAttributeValues: {
        ':active': newStatus
      },
      ReturnValues: 'ALL_NEW'
    };

    const { Attributes: updatedUser } = await docClient.send(new UpdateCommand(updateParams));

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        message: `User ${newStatus ? 'activated' : 'deactivated'} successfully`,
        user: updatedUser
      })
    };

  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        message: 'Internal server error',
        error: error.message
      })
    };
  }
};
  