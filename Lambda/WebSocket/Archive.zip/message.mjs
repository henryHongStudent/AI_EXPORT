import {
  ApiGatewayManagementApiClient,
  PostToConnectionCommand,
} from "@aws-sdk/client-apigatewaymanagementapi";
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { v4 as uuidv4 } from "uuid";
import OpenAI from "openai";
import { prompt } from "./prompt.mjs";
import axios from "axios";
import { PDFDocument } from "pdf-lib";
import pdfImgConvert from "pdf-img-convert";

// ====================================
// 설정 및 초기화
// ====================================
console.log("============== 모듈 초기화 ==============");
const ENDPOINT = process.env.WEBSOCKET_ENDPOINT;
const api = new ApiGatewayManagementApiClient({ endpoint: ENDPOINT });
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const s3Client = new S3Client({
  region: `${process.env.REGION}`,
  credentials: {
    accessKeyId: `${process.env.ACCESS_KEY_ID}`,
    secretAccessKey: `${process.env.SECRET_ACCESS_KEY}`,
  },
});

const BUCKET_NAME = process.env.S3_BUCKET;
console.log(
  `============== 설정 완료: 버킷=${BUCKET_NAME}, 엔드포인트=${ENDPOINT} ==============`
);

/**
 * PDF 버퍼를 이미지로 변환
 * @param {Buffer} pdfBuffer - PDF 파일의 버퍼
 * @returns {Promise<Buffer>} - 이미지 버퍼
 */
async function convertPdfBufferToImage(pdfBuffer) {
  console.log(`============== PDF 버퍼를 이미지로 변환 시작 ==============`);

  try {
    // PDF 문서 로드
    const pdfDoc = await PDFDocument.load(pdfBuffer);
    const pageCount = pdfDoc.getPageCount();

    console.log(`PDF 페이지 수: ${pageCount}`);

    if (pageCount === 0) {
      throw new Error("PDF에 페이지가 없습니다.");
    }

    // 첫 페이지만 처리 (필요시 모든 페이지 처리로 확장 가능)
    const page = pdfDoc.getPage(0);
    const { width, height } = page.getSize();

    // 새 PDF 문서 생성 (첫 페이지만 포함)
    const singlePagePdf = await PDFDocument.create();
    const [copiedPage] = await singlePagePdf.copyPages(pdfDoc, [0]);
    singlePagePdf.addPage(copiedPage);

    const singlePagePdfBytes = await singlePagePdf.save();

    // PDF를 이미지로 변환 (pdf-img-convert 사용)
    const image = await pdfImgConvert.convert(Buffer.from(singlePagePdfBytes), {
      width: width,
      height: height,
      base64: false,
    });

    console.log(
      `============== PDF를 이미지로 변환 완료: ${width}x${height} ==============`
    );
    return image[0]; // 첫 페이지 이미지 반환
  } catch (error) {
    console.error("PDF 변환 에러:", error);
    throw new Error(
      `PDF를 이미지로 변환하는 데 실패했습니다: ${error.message}`
    );
  }
}

/**
 * PDF URL에서 PDF 버퍼를 가져옴
 * @param {string} pdfUrl - PDF 파일의 URL
 * @returns {Promise<Buffer>} - PDF 버퍼
 */
async function getPdfBufferFromUrl(pdfUrl) {
  console.log(
    `============== PDF URL에서 버퍼 가져오기: ${pdfUrl} ==============`
  );

  try {
    const response = await axios.get(pdfUrl, { responseType: "arraybuffer" });
    return Buffer.from(response.data);
  } catch (error) {
    console.error("PDF 다운로드 에러:", error);
    throw new Error(`PDF 다운로드에 실패했습니다: ${error.message}`);
  }
}

/**
 * Uploads a file to S3 with a unique filename
 * @param {Object} fileData - The file data object
 * @param {Buffer} fileData.content - File content as Buffer
 * @param {string} fileData.fileName - Original file name
 * @param {string} fileData.contentType - File content type
 * @param {string} fileData.username - Username for organizing files
 * @returns {Promise<Object>} - The S3 upload result
 */
export const saveToS3 = async (fileData) => {
  console.log("============== S3 업로드 시작 ==============");
  console.log(`파일명: ${fileData.fileName}, 타입: ${fileData.contentType}`);

  try {
    // Extract file information
    const { content, fileName, contentType, username } = fileData;

    // Validate required parameters
    if (!content || !fileName) {
      throw new Error("Missing required parameters: content or fileName");
    }

    // Extract the file extension from the original filename
    const fileExtension = fileName.split(".").pop().toLowerCase();

    // Generate a unique file ID
    const uniqueId = uuidv4();
    console.log(`생성된 UUID: ${uniqueId}`);

    // Create a structured key for S3 (username/uniqueId_filename.ext)
    const folderPrefix = username
      ? `${username.replace(/[^a-zA-Z0-9]/g, "_")}/`
      : "";
    const key = `${folderPrefix}${uniqueId}_${fileName}`;
    console.log(`S3 키 생성: ${key}`);

    // Determine content type if not provided
    let detectedContentType = contentType;
    if (!detectedContentType) {
      if (fileExtension === "pdf") {
        detectedContentType = "application/pdf";
      } else if (["png", "jpg", "jpeg", "gif"].includes(fileExtension)) {
        detectedContentType = `image/${
          fileExtension === "jpg" ? "jpeg" : fileExtension
        }`;
      } else {
        detectedContentType = "application/octet-stream";
      }
    }
    console.log(`콘텐츠 타입: ${detectedContentType}`);

    // Set up S3 upload parameters
    const params = {
      Bucket: BUCKET_NAME,
      Key: key,
      Body: content,
      ContentType: detectedContentType,
      ACL: "public-read", // Make the file publicly accessible
    };

    // Upload to S3
    console.log("S3 업로드 시작...");
    await s3Client.send(new PutObjectCommand(params));
    console.log(`============== S3 업로드 성공: ${key} ==============`);

    // Generate and return the S3 URL
    const s3Url = `https://${BUCKET_NAME}.s3.${
      process.env.AWS_REGION || "ap-southeast-2"
    }.amazonaws.com/${key}`;
    console.log(`생성된 S3 URL: ${s3Url}`);

    return {
      success: true,
      message: "File uploaded successfully",
      url: s3Url,
      key: key,
      fileName: fileName,
    };
  } catch (error) {
    console.error("============== S3 업로드 에러 ==============", error);
    return {
      success: false,
      message: `Failed to upload file: ${error.message}`,
      error: error.toString(),
    };
  }
};

/**
 * Send a message to the connected client through WebSocket
 */
export const sendMessage = async (connectionId, message) => {
  console.log(`============== 메시지 전송 (${message.type}) ==============`);
  console.log("전송 데이터:", JSON.stringify(message));

  try {
    const command = new PostToConnectionCommand({
      ConnectionId: connectionId,
      Data: JSON.stringify(message),
    });

    await api.send(command);
    console.log(
      `메시지 전송 성공 (${message.type}) - ConnectionId: ${connectionId}`
    );
    return true;
  } catch (error) {
    console.error(
      `============== 메시지 전송 실패 (${message.type}) ==============`,
      error
    );
    if (error.name === "GoneException") {
      console.log("클라이언트 연결이 끊어짐:", connectionId);
    }
    return false;
  }
};

/**
 * Handle WebSocket messages
 */

/**
 * Handle WebSocket messages
 */
export const handleMessage = async (connectionId, message) => {
  console.log("============== 메시지 핸들러 시작 ==============");
  console.log(`ConnectionId: ${connectionId}`);
  console.log(`Raw message: ${message}`);

  try {
    const data = JSON.parse(message);
    console.log(`메시지 타입: ${data.type}`);
    console.log("파싱된 데이터:", JSON.stringify(data, null, 2));

    // 파일 업로드 처리
    if (data.type === "UPLOAD_FILE") {
      console.log("============== 파일 업로드 처리 시작 ==============");

      // 파일 업로드 시작 알림
      await sendMessage(connectionId, {
        type: "UPLOAD_STARTED",
        jobId: data.jobId || uuidv4(),
        message: "파일 업로드 시작",
        timestamp: new Date().toISOString(),
      });

      const uploadResults = [];
      const files = Array.isArray(data.files) ? data.files : [data.files];
      console.log(`처리할 파일 수: ${files.length}`);

      // 각 파일 처리
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        console.log(
          `============== 파일 업로드 [${i}/${files.length}] ==============`
        );
        console.log(`파일명: ${file.fileName}`);

        // 업로드 진행 상태 알림
        await sendMessage(connectionId, {
          type: "UPLOADING_FILE",
          jobId: data.jobId,
          fileName: file.fileName,
          status: "uploading",
          index: i,
          total: files.length,
          timestamp: new Date().toISOString(),
        });

        try {
          console.log(`파일 내용 길이(base64): ${file.base64Content.length}`);
          // S3에 파일 업로드
          const uploadResult = await saveToS3({
            content: Buffer.from(file.base64Content, "base64"),
            fileName: file.fileName,
            contentType: file.contentType,
            username: data.username,
          });

          if (uploadResult.success) {
            console.log(`파일 업로드 성공: ${file.fileName}`);
            uploadResults.push({
              fileName: file.fileName,
              pdfUrl: uploadResult.url,
              key: uploadResult.key,
              success: true,
            });

            // 파일 업로드 완료 알림
            await sendMessage(connectionId, {
              type: "FILE_UPLOADED",
              jobId: data.jobId,
              fileName: file.fileName,
              status: "uploaded",
              url: uploadResult.url,
              key: uploadResult.key,
              index: i,
              total: files.length,
              timestamp: new Date().toISOString(),
            });
          } else {
            console.error(
              `파일 업로드 실패: ${file.fileName}`,
              uploadResult.message
            );
            uploadResults.push({
              fileName: file.fileName,
              error: uploadResult.message,
              success: false,
            });

            // 파일 업로드 실패 알림
            await sendMessage(connectionId, {
              type: "FILE_UPLOAD_ERROR",
              jobId: data.jobId,
              fileName: file.fileName,
              status: "error",
              error: uploadResult.message,
              index: i,
              total: files.length,
              timestamp: new Date().toISOString(),
            });
          }
        } catch (error) {
          console.error(
            `============== 파일 업로드 예외 발생 [${i}] ==============`,
            error
          );
          uploadResults.push({
            fileName: file.fileName,
            error: error.message,
            success: false,
          });

          await sendMessage(connectionId, {
            type: "FILE_UPLOAD_ERROR",
            jobId: data.jobId,
            fileName: file.fileName,
            status: "error",
            error: error.message,
            index: i,
            total: files.length,
            timestamp: new Date().toISOString(),
          });
        }
      }

      // 모든 파일 업로드 완료 알림
      console.log("============== 모든 파일 업로드 완료 ==============");
      await sendMessage(connectionId, {
        type: "UPLOAD_COMPLETED",
        jobId: data.jobId,
        results: uploadResults,
        timestamp: new Date().toISOString(),
      });

      // 업로드 완료 후 자동으로 문서 처리 시작
      console.log(
        "============== 업로드 완료 후 자동 문서 처리 시작 =============="
      );

      // 처리 시작 알림
      await sendMessage(connectionId, {
        type: "PROCESSING_STARTED",
        jobId: data.jobId,
        message: "문서 처리 시작",
        total: uploadResults.length,
        timestamp: new Date().toISOString(),
      });

      // 성공적으로 업로드된 파일만 필터링
      const successfulUploads = uploadResults.filter((file) => file.success);

      // 처리할 파일이 없는 경우
      if (successfulUploads.length === 0) {
        console.log("============== 처리할 파일이 없음 ==============");
        await sendMessage(connectionId, {
          type: "PROCESSING_COMPLETED",
          jobId: data.jobId,
          results: [],
          message: "처리할 파일이 없습니다. 모든 파일 업로드가 실패했습니다.",
          timestamp: new Date().toISOString(),
        });

        return {
          type: "SUCCESS",
          message: "모든 파일 업로드 완료되었으나 처리할 파일이 없습니다.",
          uploadResults: uploadResults,
          processingResults: [],
        };
      }

      // 파일별로 처리
      const processingResults = [];
      for (let i = 0; i < successfulUploads.length; i++) {
        const file = successfulUploads[i];
        console.log(
          `============== 파일 처리 [${i + 1}/${
            successfulUploads.length
          }] ==============`
        );
        console.log(`파일명: ${file.fileName}`);

        // 처리 시작 알림
        await sendMessage(connectionId, {
          type: "PROCESSING_FILE",
          jobId: data.jobId,
          fileName: file.fileName,
          status: "processing",
          index: i,
          total: successfulUploads.length,
          timestamp: new Date().toISOString(),
          message: `${file.fileName} 파일 처리 시작`,
        });

        try {
          // 파일 URL 확인
          const pdfUrl = file.pdfUrl;
          if (!pdfUrl) {
            throw new Error("파일 URL이 제공되지 않았습니다.");
          }

          // OpenAI 호출 준비 알림
          await sendMessage(connectionId, {
            type: "PROCESSING_PROGRESS",
            jobId: data.jobId,
            fileName: file.fileName,
            status: "preparing",
            progress: 25,
            index: i,
            total: successfulUploads.length,
            message: "OpenAI API 호출 준비 중",
            timestamp: new Date().toISOString(),
          });

          console.log(
            `============== OpenAI API 호출 - 파일: ${pdfUrl} ==============`
          );
          const startTime = new Date();

          // OpenAI 호출 시작 알림
          await sendMessage(connectionId, {
            type: "PROCESSING_PROGRESS",
            jobId: data.jobId,
            fileName: file.fileName,
            status: "analyzing",
            progress: 50,
            index: i,
            total: successfulUploads.length,
            message: "OpenAI가 문서를 분석 중입니다",
            timestamp: new Date().toISOString(),
          });

          const response = await openai.chat.completions.create({
            model: "gpt-4o-mini",
            messages: [
              {
                role: "user",
                content: [
                  { type: "text", text: prompt },
                  { type: "image_url", image_url: { url: pdfUrl } },
                ],
              },
            ],
            response_format: { type: "json_object" },
          });

          // OpenAI 응답 수신 알림
          await sendMessage(connectionId, {
            type: "PROCESSING_PROGRESS",
            jobId: data.jobId,
            fileName: file.fileName,
            status: "parsing",
            progress: 75,
            index: i,
            total: successfulUploads.length,
            message: "OpenAI 응답 수신 및 파싱 중",
            timestamp: new Date().toISOString(),
          });

          const endTime = new Date();
          const processingTime = (endTime - startTime) / 1000;
          console.log(`OpenAI API 응답 완료 (${processingTime}초 소요)`);
          console.log(
            `응답 토큰 수: ${response.usage?.total_tokens || "알 수 없음"}`
          );

          const result = response.choices[0]?.message?.content;
          console.log("응답 데이터:", result);

          const parsedResult = result ? JSON.parse(result) : null;
          processingResults.push({
            name: file.fileName,
            data: parsedResult,
            processingTime: processingTime,
            tokens: response.usage?.total_tokens,
          });

          // 파일 처리 완료 알림
          console.log(
            `============== 파일 처리 완료 [${i + 1}/${
              successfulUploads.length
            }] ==============`
          );
          await sendMessage(connectionId, {
            type: "FILE_PROCESSED",
            jobId: data.jobId,
            fileName: file.fileName,
            status: "done",
            result: parsedResult,
            index: i,
            total: successfulUploads.length,
            processingTime: processingTime,
            tokens: response.usage?.total_tokens,
            timestamp: new Date().toISOString(),
            message: `${file.fileName} 파일 처리 완료 (${processingTime}초 소요)`,
          });

          // 다음 파일 처리 전 진행 상황 업데이트
          if (i < successfulUploads.length - 1) {
            await sendMessage(connectionId, {
              type: "PROCESSING_PROGRESS",
              jobId: data.jobId,
              status: "ongoing",
              progress: Math.round(((i + 1) / successfulUploads.length) * 100),
              completed: i + 1,
              total: successfulUploads.length,
              message: `${i + 1}/${
                successfulUploads.length
              } 파일 처리 완료, 다음 파일 처리 준비 중`,
              timestamp: new Date().toISOString(),
            });
          }
        } catch (error) {
          console.error(
            `============== OpenAI API 호출 에러 [${i + 1}/${
              successfulUploads.length
            }] ==============`,
            error
          );
          processingResults.push({
            name: file.fileName,
            error: error.message,
          });

          // 에러 발생 알림
          await sendMessage(connectionId, {
            type: "FILE_ERROR",
            jobId: data.jobId,
            fileName: file.fileName,
            status: "error",
            error: error.message,
            errorDetails: error.stack,
            index: i,
            total: successfulUploads.length,
            timestamp: new Date().toISOString(),
            message: `${file.fileName} 파일 처리 중 오류 발생: ${error.message}`,
          });
        }
      }

      // 전체 처리 완료 알림
      console.log("============== 모든 파일 처리 완료 ==============");

      // 성공 및 실패 파일 수 계산
      const successCount = processingResults.filter(
        (result) => !result.error
      ).length;
      const failCount = processingResults.length - successCount;

      await sendMessage(connectionId, {
        type: "PROCESSING_COMPLETED",
        jobId: data.jobId,
        results: processingResults,
        summary: {
          total: processingResults.length,
          success: successCount,
          failed: failCount,
        },
        timestamp: new Date().toISOString(),
        message: `모든 파일 처리 완료 (성공: ${successCount}, 실패: ${failCount})`,
      });

      return {
        type: "SUCCESS",
        message: "모든 파일 업로드 및 처리 완료",
        uploadResults: uploadResults,
        processingResults: processingResults,
        summary: {
          upload: {
            total: uploadResults.length,
            success: successfulUploads.length,
            failed: uploadResults.length - successfulUploads.length,
          },
          processing: {
            total: processingResults.length,
            success: successCount,
            failed: failCount,
          },
        },
      };
    }

    if (data.type === "START_PROCESSING") {
      console.log("============== 문서 처리 시작 ==============");

      // 처리 시작 알림
      await sendMessage(connectionId, {
        type: "PROCESSING_STARTED",
        jobId: data.jobId,
        message: "문서 처리 시작",
        total: data.files.length,
        timestamp: new Date().toISOString(),
      });

      // 파일별로 처리
      const results = [];
      for (let i = 0; i < data.files.length; i++) {
        const file = data.files[i];
        console.log(
          `============== 파일 처리 [${i}/${data.files.length}] ==============`
        );
        console.log(`파일명: ${file.fileName || file.imageName}`);

        await sendMessage(connectionId, {
          type: "PROCESSING_FILE",
          jobId: data.jobId,
          fileName: file.fileName || file.imageName,
          status: "processing",
          index: i,
          total: data.files.length,
          timestamp: new Date().toISOString(),
        });

        try {
          // 파일 URL 확인
          const pdfUrl = file.pdfUrl || file.url;
          if (!pdfUrl) {
            throw new Error("파일 URL이 제공되지 않았습니다.");
          }

          console.log(
            `============== OpenAI API 호출 - 파일: ${pdfUrl} ==============`
          );
          const startTime = new Date();

          const response = await openai.chat.completions.create({
            model: "gpt-4o-mini",
            messages: [
              {
                role: "user",
                content: [
                  { type: "text", text: prompt },
                  { type: "image_url", image_url: { url: pdfUrl } },
                ],
              },
            ],
            response_format: { type: "json_object" },
          });

          const endTime = new Date();
          const processingTime = (endTime - startTime) / 1000;
          console.log(`OpenAI API 응답 완료 (${processingTime}초 소요)`);
          console.log(
            `응답 토큰 수: ${response.usage?.total_tokens || "알 수 없음"}`
          );

          const result = response.choices[0]?.message?.content;
          console.log("응답 데이터:", result);

          const parsedResult = result ? JSON.parse(result) : null;
          results.push({
            name: file.fileName || file.imageName,
            data: parsedResult,
          });

          // 파일 처리 완료 알림
          console.log(`============== 파일 처리 완료 [${i}] ==============`);
          await sendMessage(connectionId, {
            type: "FILE_PROCESSED",
            jobId: data.jobId,
            fileName: file.fileName || file.imageName,
            status: "done",
            result: parsedResult,
            index: i,
            total: data.files.length,
            processingTime: processingTime,
            timestamp: new Date().toISOString(),
          });
        } catch (error) {
          console.error(
            `============== OpenAI API 호출 에러 [${i}] ==============`,
            error
          );
          results.push({
            name: file.fileName || file.imageName,
            error: error.message,
          });

          await sendMessage(connectionId, {
            type: "FILE_ERROR",
            jobId: data.jobId,
            fileName: file.fileName || file.imageName,
            status: "error",
            error: error.message,
            index: i,
            total: data.files.length,
            timestamp: new Date().toISOString(),
          });
        }
      }

      // 전체 처리 완료 알림
      console.log("============== 모든 파일 처리 완료 ==============");
      await sendMessage(connectionId, {
        type: "PROCESSING_COMPLETED",
        jobId: data.jobId,
        results: results,
        timestamp: new Date().toISOString(),
      });

      // 여기서 연결을 종료하지 않고 클라이언트가 메시지를 받을 수 있도록 유지
      console.log("처리 완료 - 연결 유지");

      return {
        type: "SUCCESS",
        message: "모든 파일 처리 완료",
        results: results,
      };
    }

    // 테스트용 PING 메시지 처리
    if (data.type === "PING") {
      console.log("============== PING 메시지 수신 ==============");
      await sendMessage(connectionId, {
        type: "PONG",
        message: "pong!",
        timestamp: new Date().toISOString(),
      });

      return {
        type: "PONG",
        message: "pong!",
      };
    }

    // 메시지 타입에 따른 처리
    switch (data.type) {
      case "GET_STATUS":
        console.log("============== 상태 조회 요청 ==============");
        // 상태 조회 로직
        await sendMessage(connectionId, {
          type: "STATUS_UPDATE",
          jobId: data.jobId,
          status: "active",
          timestamp: new Date().toISOString(),
        });

        return {
          type: "STATUS_UPDATE",
          jobId: data.jobId,
          status: "active",
        };

      default:
        console.log(
          `============== 알 수 없는 메시지 타입: ${data.type} ==============`
        );
        await sendMessage(connectionId, {
          type: "ERROR",
          message: "Unknown message type",
          receivedType: data.type,
          timestamp: new Date().toISOString(),
        });

        return {
          type: "ERROR",
          message: "Unknown message type",
        };
    }
  } catch (error) {
    console.error(
      "============== 메시지 핸들러 최상위 에러 ==============",
      error
    );
    await sendMessage(connectionId, {
      type: "ERROR",
      message: error.message,
      stack: error.stack,
      timestamp: new Date().toISOString(),
    });

    // 에러 발생 시에도 연결을 유지하도록 수정
    console.log("에러 발생 - 하지만 연결은 유지");

    return {
      type: "ERROR",
      message: "Internal server error",
      error: error.message,
    };
  }
};


